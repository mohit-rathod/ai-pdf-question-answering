import warnings
warnings.filterwarnings("ignore")

import os
os.environ["TOKENIZERS_PARALLELISM"] = "false"

from db_connectorr import store_raptor_dict_in_postgres
from pdf_texts import load_pdf_texts_from_folder
from raptor import recursive_embed_cluster_summarize
from doc_retriever import return_docs
from langchain.prompts import ChatPromptTemplate
from langchain_core.output_parsers import StrOutputParser

from llm import get_llm

model = get_llm()

doc_texts = load_pdf_texts_from_folder("pdfs")

results = recursive_embed_cluster_summarize(doc_texts, level=1, n_levels=5)

store_raptor_dict_in_postgres(results)

question = "Tell me about the company Dell."
retrieved_docs_text = return_docs("question", 5)

template = """You are an expert information retrieval assistant. Your task is to answer the following question using only the information provided in the documents below. Do not incorporate any external knowledge or assumptions. If the answer is not explicitly present in the documents, respond with "I don't know." Provide a concise and accurate answer that is directly supported by the context.

Documents:
{context}

Question:
{question}

    """
prompt = ChatPromptTemplate.from_template(template)
chain = prompt | model | StrOutputParser()

answer = chain.invoke({"context": retrieved_docs_text, "question": question})
print(retrieved_docs_text)
print("\n\n")
print(answer)